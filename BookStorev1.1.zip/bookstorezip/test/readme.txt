/**
 * @Date       25-06-2020
 * @Author     Sapan Mohanty
 * @Skype      sapan.mohannty
 * @github     https://github.com/travelxml
 */

Basic testing done for all functions like create, update, read & delete book
This can be extend with more functionalities like input and output validation & parameters matching 


All this test conducted using HTTP_Request2 PEAR library

https://pear.php.net/manual/en/package.http.http-request2.config.php